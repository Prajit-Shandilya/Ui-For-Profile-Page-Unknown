import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text
        style={{
          alignSelf: 'center',
          fontSize: 30,
          marginTop: '10%',
        }}>
        Profile Page
      </Text>
      <Image
        source={require('./photo_2021-11-25_19-17-58.jpg')}
        style={{ width: 170, height: 170,alignSelf:'center',marginTop:'50%' }}

        
      />
      <Text style={{alignSelf:'center',fontSize:25,color:'red',marginTop:'10%'}}>Prajit Shandilya</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
